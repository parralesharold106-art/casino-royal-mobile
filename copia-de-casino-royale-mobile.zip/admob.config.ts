/**
 * Google AdMob Configuration
 * Cuenta: harry.7u7@gmail.com
 */

// Test IDs (para desarrollo y pruebas)
export const ADMOB_TEST_IDS = {
  android: {
    banner: "ca-app-pub-3940256099942544/6300978111",
    interstitial: "ca-app-pub-3940256099942544/1033173712",
    rewarded: "ca-app-pub-3940256099942544/5224354917",
  },
  ios: {
    banner: "ca-app-pub-3940256099942544/2934735716",
    interstitial: "ca-app-pub-3940256099942544/4411468910",
    rewarded: "ca-app-pub-3940256099942544/1712485313",
  },
};

// Production IDs (reemplaza con tus IDs reales de AdMob)
export const ADMOB_PRODUCTION_IDS = {
  android: {
    banner: process.env.ADMOB_ANDROID_BANNER || ADMOB_TEST_IDS.android.banner,
    interstitial: process.env.ADMOB_ANDROID_INTERSTITIAL || ADMOB_TEST_IDS.android.interstitial,
    rewarded: process.env.ADMOB_ANDROID_REWARDED || ADMOB_TEST_IDS.android.rewarded,
  },
  ios: {
    banner: process.env.ADMOB_IOS_BANNER || ADMOB_TEST_IDS.ios.banner,
    interstitial: process.env.ADMOB_IOS_INTERSTITIAL || ADMOB_TEST_IDS.ios.interstitial,
    rewarded: process.env.ADMOB_IOS_REWARDED || ADMOB_TEST_IDS.ios.rewarded,
  },
};

// Seleccionar IDs basado en el ambiente
const isProduction = process.env.NODE_ENV === "production";
export const ADMOB_CONFIG = isProduction ? ADMOB_PRODUCTION_IDS : ADMOB_TEST_IDS;

/**
 * Configuración de estrategia de anuncios
 */
export const ADMOB_STRATEGY = {
  // Banner: Mostrar siempre en la parte inferior
  banner: {
    enabled: true,
    placement: "bottom",
    refreshRate: 30000, // 30 segundos
  },

  // Intersticial: Mostrar después de cada 3 juegos
  interstitial: {
    enabled: true,
    frequency: 3, // Cada 3 juegos
    showProbability: 0.8, // 80% de probabilidad
  },

  // Video Recompensado: Ofrecimiento voluntario
  rewarded: {
    enabled: true,
    reward: 50, // Fichas por ver anuncio
    placement: "bonus_screen",
  },
};

/**
 * Proyecciones de ingresos
 */
export const ADMOB_REVENUE_PROJECTIONS = {
  conservativeDAU: 1000,
  moderateDAU: 5000,
  aggressiveDAU: 10000,
  
  estimatedCPM: 5, // $5 por 1000 impresiones
  estimatedCTR: 0.02, // 2% click-through rate
  
  // Cálculos
  getEstimatedDailyRevenue: (dau: number) => {
    const impressions = dau * 10; // ~10 impresiones por usuario
    const revenue = (impressions / 1000) * ADMOB_REVENUE_PROJECTIONS.estimatedCPM;
    return revenue;
  },
};

/**
 * Mejores prácticas de AdMob
 */
export const ADMOB_BEST_PRACTICES = [
  "✅ Nunca hagas clic en tus propios anuncios",
  "✅ No incentives a usuarios a hacer clic",
  "✅ Mantén la app funcionando correctamente",
  "✅ Cumple con las políticas de Google Play",
  "✅ Monitorea tus ingresos diariamente",
  "✅ Optimiza la colocación de anuncios",
  "✅ A/B test diferentes estrategias",
  "✅ Responde a usuarios sobre los anuncios",
];

/**
 * Obtener ID de unidad publicitaria
 */
export function getAdUnitId(type: "banner" | "interstitial" | "rewarded", platform: "android" | "ios"): string {
  return ADMOB_CONFIG[platform][type];
}

/**
 * Verificar si AdMob está habilitado
 */
export function isAdMobEnabled(): boolean {
  return ADMOB_STRATEGY.banner.enabled || ADMOB_STRATEGY.interstitial.enabled || ADMOB_STRATEGY.rewarded.enabled;
}

/**
 * Obtener estrategia de anuncios
 */
export function getAdStrategy() {
  return ADMOB_STRATEGY;
}
