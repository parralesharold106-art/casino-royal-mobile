# Build Casino Royal Mobile with GitHub and EAS

This repository is configured to produce an Android APK for **Amazon Appstore** and an Android App Bundle for **Google Play**. The Android package identifier is **`com.casinomobile.app`**. The Amazon profile uses an APK because Amazon accepts Android APK packages; the Google Play profile uses an AAB. [1] [2]

## Included build profiles

| Profile | Output | Intended use |
|---|---|---|
| `amazon` | Signed `.apk` | Upload to Amazon Appstore after validation. |
| `google-play` | Signed `.aab` | Upload to Google Play Console. |
| `preview` | Installable `.apk` | Test on Android or Fire TV before store submission. |

## One-time account setup

Upload this source folder to a private GitHub repository. Then sign in to the Expo account that owns the EAS project and run the following commands in a terminal from the project root:

```bash
npm exec --yes pnpm@9.12.0 -- install --frozen-lockfile
npx eas-cli@latest init
npx eas-cli@latest credentials --platform android
```

The first command initializes or links the project to the Expo account and writes its EAS project identifier into the Expo configuration. The credentials command lets the account owner upload or select the existing Android signing key for `com.casinomobile.app`. Do not commit the keystore, passwords, access tokens, or API keys to GitHub.

Create an Expo personal access token in the Expo account, then add it as a GitHub repository secret named **`EXPO_TOKEN`**. This secret is consumed only by the GitHub workflow and must never be written into any source file. EAS CI builds require this token in non-interactive environments. [3]

## Build through GitHub

Open the repository’s **Actions** page, select **Build Android for Amazon or Google Play**, choose **Run workflow**, and select the required profile:

```text
amazon       → signed APK for Amazon Appstore
google-play  → signed AAB for Google Play Console
preview      → installable validation APK
```

The workflow installs the lockfile-pinned dependencies, runs TypeScript and automated tests, validates the Expo configuration, and only then triggers the selected EAS build. EAS returns a build URL in the workflow log. Download the artifact from that EAS build page.

## Local verification commands

Run these commands before pushing a release commit:

```bash
npm exec --yes pnpm@9.12.0 -- install --frozen-lockfile
npm exec --yes pnpm@9.12.0 -- run validate:release
```

## Amazon Appstore re-submission

Before uploading the replacement APK, use the current Fire TV build to make three real 1920 × 1080 screenshots: Home, Slots, and Roulette or Blackjack. They must depict the actual submitted build, including the corrected non-overlapping layout. In Amazon Developer Console, paste the English metadata in `AMAZON_APPSTORE_RESUBMISSION.md`, replace the screenshots, and upload the new APK.

## References

[1]: https://docs.expo.dev/build-reference/apk/ "Expo: Build APKs for Android Emulators and devices"
[2]: https://docs.expo.dev/build/eas-json/ "Expo: Configure EAS Build with eas.json"
[3]: https://docs.expo.dev/build/building-on-ci/ "Expo: Trigger builds from CI"
