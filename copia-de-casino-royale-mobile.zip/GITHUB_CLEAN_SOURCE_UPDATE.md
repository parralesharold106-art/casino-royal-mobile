# Actualización limpia de GitHub para Expo, EAS y Amazon

El ZIP de entrega contiene solamente código, activos, configuración de Expo/EAS, flujos de GitHub, pruebas y documentación. **No incluye** `node_modules`, builds Android, APK/AAB, keystores, archivos `.env`, registros ni cachés. Esos elementos son reproducibles o sensibles y no deben entrar al repositorio.

## Procedimiento recomendado

Primero, cree una rama nueva en GitHub, por ejemplo `release/amazon-fix`. Extraiga el ZIP en esa rama y reemplace los archivos de la raíz. No suba ninguna carpeta `node_modules`, ningún APK/AAB, ni archivos de firma de Android.

Conserve el archivo público `assets/amazon/AppstoreAuthenticationKey.pem` cuando vaya a compilar la próxima actualización Amazon. No es un keystore de firma; el complemento de Amazon IAP lo inserta como un activo requerido durante el prebuild.

Después de confirmar los cambios, ejecute manualmente el flujo **Clean generated files before EAS build** desde GitHub Actions. Al solicitar confirmación, escriba exactamente:

```text
DELETE_ONLY_GENERATED_FILES
```

El flujo no elimina código TypeScript, activos `assets/`, `AppstoreAuthenticationKey.pem`, `eas.json`, flujos de GitHub, archivos de configuración ni documentación. Solo elimina dependencias, binarios, credenciales de firma, cachés y otros artefactos recreables.

## Mensaje de commit

```text
feat(amazon): actualizar Casino Royal Mobile con RevenueCat y Amazon IAP

- Corrige navegación, controles y estabilidad de Tragamonedas.
- Configura Expo/EAS para APK Amazon con el paquete com.casinomobile.app.
- Integra react-native-purchases con RevenueCat y useAmazon: true.
- Carga fichas y beneficios VIP desde los offerings de RevenueCat.
- Oculta pagos externos en el perfil Amazon.
- Añade flujo GitHub Actions, validaciones y guía de EAS.
- Requiere AppstoreAuthenticationKey.pem y la clave pública RevenueCat en EAS production.
```

## Antes de iniciar EAS

Verifique que `EXPO_TOKEN` y `EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY` existan como secretos de GitHub y que la última clave también exista en el entorno `production` de EAS. Solo después ejecute **Build Android for Amazon or Google Play** con el perfil `amazon`.
