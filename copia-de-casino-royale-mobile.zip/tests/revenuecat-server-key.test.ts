import { describe, expect, it } from "vitest";

const apiKey = process.env.REVENUECAT_SECRET_API_KEY;

describe("RevenueCat server key", () => {
  it("is accepted by the RevenueCat subscriber API", async () => {
    expect(apiKey, "Configura REVENUECAT_SECRET_API_KEY antes de activar la verificación de compras.").toBeTruthy();

    const response = await fetch(
      "https://api.revenuecat.com/v1/subscribers/$RCAnonymousID:casino-royal-server-key-check",
      {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "X-Platform": "amazon",
        },
      },
    );

    expect(response.status, "La clave privada de RevenueCat debe autorizar la API de suscriptores.").toBeLessThan(400);
  }, 15_000);
});
