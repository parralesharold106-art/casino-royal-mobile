import { describe, expect, it } from "vitest";

const apiKey = process.env.EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY;

describe("RevenueCat Amazon SDK key", () => {
  it("is accepted by the RevenueCat subscriber endpoint", async () => {
    expect(apiKey, "Configura EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY antes de compilar Amazon.").toBeTruthy();

    const response = await fetch(
      "https://api.revenuecat.com/v1/subscribers/$RCAnonymousID:casino-royal-amazon-key-check",
      {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "X-Platform": "amazon",
        },
      },
    );

    expect(response.status, "La clave de SDK de Amazon debe ser aceptada por RevenueCat.").toBeLessThan(400);
  }, 15_000);
});
