# Amazon Appstore Authentication Key

Place the public file named `AppstoreAuthenticationKey.pem` in this directory before creating the next Amazon build.

The Amazon RevenueCat configuration plugin copies this file into the generated Android assets directory. This is the public authentication key issued by Amazon Developer Console for the Appstore SDK; it is not a private signing key.

The file is intentionally absent from this repository until it is downloaded from the Amazon Developer Console for the next app version.
