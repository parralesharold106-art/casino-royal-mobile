# RevenueCat and Amazon Appstore Setup

The current Amazon-approved release is not changed by these files. This integration is for a later app update built from the `amazon` EAS profile.

## What the code does

The Amazon build profile sets `APP_STORE=amazon`. The application then initializes `react-native-purchases` with the validated Amazon RevenueCat public SDK key and `useAmazon: true`. The chip store loads packages from the RevenueCat current offering and starts the purchase flow through Amazon Appstore, not PayPal or Google Play Billing.

## Required dashboard setup before an Amazon build

1. In Amazon Developer Console, create every Amazon IAP item and submit it with the app. Use unique, case-sensitive SKUs.
2. In RevenueCat, add an Amazon Appstore app with package name `com.casinomobile.app` and its Amazon shared secret. Import the Amazon products, attach them to the intended entitlement, and add them to the current offering.
3. Download `AppstoreAuthenticationKey.pem` from the Amazon Developer Console for the upcoming version. Save it at `assets/amazon/AppstoreAuthenticationKey.pem` and commit this public key with the next source update. The Amazon SDK requires this public authentication key in the generated Android assets.
4. In GitHub, add the repository secret `EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY` with the Amazon Public SDK Key from RevenueCat. This public SDK key is injected for the validation job; configure the same variable in the EAS production environment used by the Amazon build.
5. Build with the `amazon` EAS profile. The build deliberately fails if the PEM file is missing, because an Amazon IAP build without it is incomplete.

## Verification

Use a physical Amazon-compatible device with a signed-in Amazon account. RevenueCat validates Amazon purchases in production and Live App Testing; Amazon App Tester purchases are not validated by RevenueCat.

## Store separation

The Amazon profile initializes RevenueCat with `useAmazon: true`. The Google Play profile sets `APP_STORE=google-play`, so it does not use Amazon billing. This repository does not enable Google Play Billing automatically.

## References

- Amazon Appstore SDK IAP: https://developer.amazon.com/docs/in-app-purchasing/iap-implement-iap.html
- RevenueCat React Native Amazon setup: https://www.revenuecat.com/docs/getting-started/installation/reactnative
- RevenueCat Amazon products: https://www.revenuecat.com/docs/getting-started/entitlements/amazon-product-setup
