export const WIDE_TV_BREAKPOINT = 900;

/**
 * Keeps the living-room layout active on native television devices and on
 * wide browser/device windows used by Fire TV validation tools.
 */
export function usesWideTvLayout(width: number, isTelevision: boolean | undefined): boolean {
  return isTelevision === true || width >= WIDE_TV_BREAKPOINT;
}
