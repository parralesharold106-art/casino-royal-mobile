import { describe, expect, it } from "vitest";

import { WIDE_TV_BREAKPOINT, usesWideTvLayout } from "./fire-tv-layout";

describe("usesWideTvLayout", () => {
  it("keeps the standard mobile layout below the Fire TV breakpoint", () => {
    expect(usesWideTvLayout(390, false)).toBe(false);
    expect(usesWideTvLayout(WIDE_TV_BREAKPOINT - 1, false)).toBe(false);
  });

  it("enables a non-overlapping wide layout at the configured breakpoint", () => {
    expect(usesWideTvLayout(WIDE_TV_BREAKPOINT, false)).toBe(true);
    expect(usesWideTvLayout(1920, false)).toBe(true);
  });

  it("always enables the wide layout on a native television device", () => {
    expect(usesWideTvLayout(480, true)).toBe(true);
  });
});
