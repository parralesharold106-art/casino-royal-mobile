import Constants from "expo-constants";
import { Platform } from "react-native";
import Purchases, { LOG_LEVEL, type CustomerInfo, type PurchasesPackage } from "react-native-purchases";

import {
  canInitializeAmazonRevenueCat,
  normalizeDistributionStore,
  shouldUseAmazonRevenueCat,
  type DistributionStore,
} from "@/lib/revenuecat-config";

type RevenueCatExtra = {
  distributionStore?: string;
  revenueCatAmazonApiKey?: string;
};

let initialized = false;

function getExtra(): RevenueCatExtra {
  return (Constants.expoConfig?.extra ?? {}) as RevenueCatExtra;
}

export function getDistributionStore(): DistributionStore {
  return normalizeDistributionStore(getExtra().distributionStore);
}

export function isAmazonRevenueCatBuild(): boolean {
  return shouldUseAmazonRevenueCat(getDistributionStore(), Platform.OS);
}

export async function initializeRevenueCat(): Promise<boolean> {
  const extra = getExtra();
  const store = getDistributionStore();

  if (initialized) return true;
  if (!canInitializeAmazonRevenueCat(store, Platform.OS, extra.revenueCatAmazonApiKey)) return false;

  Purchases.setLogLevel(__DEV__ ? LOG_LEVEL.DEBUG : LOG_LEVEL.WARN);
  Purchases.configure({
    apiKey: extra.revenueCatAmazonApiKey!.trim(),
    useAmazon: true,
  });
  initialized = true;
  return true;
}

export async function getAmazonPackages(): Promise<PurchasesPackage[]> {
  const isReady = await initializeRevenueCat();
  if (!isReady) return [];

  const offerings = await Purchases.getOfferings();
  return offerings.current?.availablePackages ?? [];
}

export async function purchaseAmazonPackage(aPackage: PurchasesPackage): Promise<CustomerInfo> {
  const isReady = await initializeRevenueCat();
  if (!isReady) {
    throw new Error("Amazon IAP is unavailable for this build.");
  }

  const { customerInfo } = await Purchases.purchasePackage(aPackage);
  return customerInfo;
}

export async function restoreAmazonPurchases(): Promise<CustomerInfo> {
  const isReady = await initializeRevenueCat();
  if (!isReady) {
    throw new Error("Amazon IAP is unavailable for this build.");
  }

  return Purchases.restorePurchases();
}
