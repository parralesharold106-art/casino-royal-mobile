import { describe, expect, it } from "vitest";

import { calculateSlotOutcome, createRandomReels } from "./slots-game";

describe("slots game logic", () => {
  it("creates valid reel indexes from a deterministic random source", () => {
    const reels = createRandomReels(() => 0.5);
    expect(reels).toEqual([3, 3, 3]);
  });

  it("calculates a jackpot without accessing UI animation state", () => {
    const outcome = calculateSlotOutcome([4, 4, 4], 10);
    expect(outcome).toEqual({
      message: "¡JACKPOT! 🎉 ¡💎💎💎!",
      winnings: 400,
      isWin: true,
    });
  });

  it("uses a safe, non-winning outcome for invalid or empty bets", () => {
    const outcome = calculateSlotOutcome([0, 1, 2], 0);
    expect(outcome).toEqual({ message: "¡Intenta de nuevo!", winnings: 0, isWin: false });
  });
});
