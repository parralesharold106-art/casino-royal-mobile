export type DistributionStore = "amazon" | "google-play" | "development" | "unknown";

export function normalizeDistributionStore(value: unknown): DistributionStore {
  if (value === "amazon" || value === "google-play" || value === "development") {
    return value;
  }
  return "unknown";
}

export function shouldUseAmazonRevenueCat(store: DistributionStore, platform: string): boolean {
  return store === "amazon" && platform === "android";
}

export function canInitializeAmazonRevenueCat(
  store: DistributionStore,
  platform: string,
  apiKey: string | undefined,
): boolean {
  return shouldUseAmazonRevenueCat(store, platform) && Boolean(apiKey?.trim());
}
