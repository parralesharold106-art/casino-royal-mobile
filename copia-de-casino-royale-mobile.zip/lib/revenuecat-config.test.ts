import { describe, expect, it } from "vitest";

import {
  canInitializeAmazonRevenueCat,
  normalizeDistributionStore,
  shouldUseAmazonRevenueCat,
} from "./revenuecat-config";

describe("RevenueCat Amazon configuration", () => {
  it("enables Amazon only for an Amazon Android build", () => {
    expect(shouldUseAmazonRevenueCat("amazon", "android")).toBe(true);
    expect(shouldUseAmazonRevenueCat("google-play", "android")).toBe(false);
    expect(shouldUseAmazonRevenueCat("amazon", "ios")).toBe(false);
  });

  it("requires a public SDK key before initialising Amazon", () => {
    expect(canInitializeAmazonRevenueCat("amazon", "android", "amzn_public_key")).toBe(true);
    expect(canInitializeAmazonRevenueCat("amazon", "android", "")).toBe(false);
  });

  it("normalises unknown store values safely", () => {
    expect(normalizeDistributionStore("amazon")).toBe("amazon");
    expect(normalizeDistributionStore("play")).toBe("unknown");
  });
});
