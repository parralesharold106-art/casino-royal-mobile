export const SLOT_SYMBOLS = ["🍒", "🍋", "🍊", "🎰", "💎", "👑"] as const;

const SYMBOL_MULTIPLIERS: Record<(typeof SLOT_SYMBOLS)[number], number> = {
  "🍒": 1.5,
  "🍋": 2,
  "🍊": 2.5,
  "🎰": 3,
  "💎": 4,
  "👑": 5,
};

export type SlotReels = [number, number, number];

export interface SlotSpinOutcome {
  message: string;
  winnings: number;
  isWin: boolean;
}

export function createRandomReels(random: () => number = Math.random): SlotReels {
  return [0, 1, 2].map(() => {
    const value = random();
    const safeValue = Number.isFinite(value) ? Math.min(Math.max(value, 0), 0.999999) : 0;
    return Math.floor(safeValue * SLOT_SYMBOLS.length);
  }) as SlotReels;
}

export function calculateSlotOutcome(reels: SlotReels, bet: number): SlotSpinOutcome {
  const safeBet = Number.isFinite(bet) && bet > 0 ? Math.floor(bet) : 0;
  const [first, second, third] = reels.map((index) => SLOT_SYMBOLS[index] ?? SLOT_SYMBOLS[0]);

  if (first === second && second === third) {
    const winnings = Math.floor(safeBet * (SYMBOL_MULTIPLIERS[first] ?? 2) * 10);
    return { message: `¡JACKPOT! 🎉 ¡${first}${first}${first}!`, winnings, isWin: true };
  }

  if (first === second || second === third) {
    const matchingSymbol = first === second ? first : third;
    const winnings = Math.floor(safeBet * (SYMBOL_MULTIPLIERS[matchingSymbol] ?? 1.5) * 3);
    return { message: `¡Ganaste! 🎊 ${winnings} fichas`, winnings, isWin: true };
  }

  if (reels.some((index) => index === SLOT_SYMBOLS.length - 1)) {
    const winnings = Math.floor(safeBet * 1.5);
    return { message: `¡Bonus! +${winnings} fichas`, winnings, isWin: true };
  }

  return { message: "¡Intenta de nuevo!", winnings: 0, isWin: false };
}
