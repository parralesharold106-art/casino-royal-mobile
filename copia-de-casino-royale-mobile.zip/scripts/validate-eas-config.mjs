import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

const configPath = resolve(process.cwd(), "eas.json");
const config = JSON.parse(await readFile(configPath, "utf8"));

function assert(condition, message) {
  if (!condition) {
    throw new Error(`EAS configuration error: ${message}`);
  }
}

assert(config.build?.amazon?.android?.buildType === "apk", "amazon must produce an APK");
assert(config.build?.["google-play"]?.android?.buildType === "app-bundle", "google-play must produce an AAB");
assert(config.build?.amazon?.autoIncrement === true, "amazon must auto-increment Android versions");
assert(config.build?.amazon?.environment === "production", "amazon must use the EAS production environment");
assert(config.build?.amazon?.env?.APP_STORE === "amazon", "amazon must select the Amazon RevenueCat store");
assert(config.build?.["google-play"]?.env?.APP_STORE === "google-play", "google-play must not use the Amazon RevenueCat store");
assert(config.cli?.appVersionSource === "remote", "EAS app version source must be remote");
assert(Boolean(process.env.EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY?.trim()), "RevenueCat Amazon public SDK key must be configured");

console.log("EAS profiles are valid: Amazon APK with RevenueCat Amazon and Google Play AAB are configured.");
