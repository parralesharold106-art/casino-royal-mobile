from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math


OUT = Path('/home/ubuntu/firetv-deliverables')
OUT.mkdir(parents=True, exist_ok=True)

W, H = 1920, 1080
NAVY = '#071320'
NAVY_2 = '#102844'
GOLD = '#E4B64C'
GOLD_LIGHT = '#FFE19A'
CREAM = '#FFF7E2'
MUTED = '#ADC0D0'
BURGUNDY = '#61172A'
GREEN = '#0D5A3B'
RED = '#B72B3E'
BLACK = '#15171B'


def font(size, bold=False):
    path = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    return ImageFont.truetype(path, size)


def shadowed_text(draw, xy, text, font_obj, fill, shadow=(0, 4), shadow_fill='#000000'):
    x, y = xy
    draw.text((x + shadow[0], y + shadow[1]), text, font=font_obj, fill=shadow_fill)
    draw.text((x, y), text, font=font_obj, fill=fill)


def base_canvas(title, section, balance='12,540'):
    image = Image.new('RGB', (W, H), NAVY)
    draw = ImageDraw.Draw(image)

    for i in range(H):
        t = i / H
        r = int(7 + 7 * t)
        g = int(19 + 18 * t)
        b = int(32 + 34 * t)
        draw.line((0, i, W, i), fill=(r, g, b))

    for x in range(-220, W + 220, 220):
        draw.line((x, 0, x + 320, H), fill='#122A43', width=2)

    draw.rectangle((0, 0, W, 126), fill='#06111C')
    draw.rectangle((0, 122, W, 126), fill=GOLD)
    draw.rounded_rectangle((55, 28, 113, 88), 12, fill=GOLD)
    shadowed_text(draw, (130, 29), title, font(44, True), CREAM)
    draw.text((133, 80), section, font=font(22, True), fill=GOLD)
    draw.rounded_rectangle((1512, 31, 1845, 91), 30, fill='#0E2B45', outline=GOLD, width=2)
    draw.text((1550, 48), f'FICHAS  {balance}', font=font(26, True), fill=GOLD_LIGHT)
    return image, draw


def card(draw, box, title, subtitle, accent, selected=False):
    x1, y1, x2, y2 = box
    draw.rounded_rectangle(box, 32, fill='#112A42', outline=GOLD if selected else '#2A4964', width=10 if selected else 3)
    draw.rounded_rectangle((x1 + 20, y1 + 20, x2 - 20, y2 - 108), 23, fill='#0A1B2B')
    cx, cy = (x1 + x2) // 2, (y1 + y2 - 90) // 2
    draw.ellipse((cx - 82, cy - 82, cx + 82, cy + 82), fill=accent, outline=GOLD_LIGHT, width=5)
    draw.ellipse((cx - 46, cy - 46, cx + 46, cy + 46), outline=CREAM, width=5)
    shadowed_text(draw, (x1 + 36, y2 - 88), title, font(30, True), CREAM)
    draw.text((x1 + 38, y2 - 48), subtitle, font=font(20), fill=MUTED)
    if selected:
        draw.rounded_rectangle((x2 - 78, y1 + 22, x2 - 22, y1 + 78), 16, fill=GOLD)
        draw.polygon([(x2 - 57, y1 + 36), (x2 - 57, y1 + 64), (x2 - 34, y1 + 50)], fill=NAVY)


def home_screen():
    image, draw = base_canvas('CASINO ROYAL MOBILE', 'INICIO')
    draw.text((80, 182), 'Elige tu juego', font=font(54, True), fill=CREAM)
    draw.text((82, 250), 'Navega con el control remoto para seleccionar una mesa.', font=font(26), fill=MUTED)
    y1, y2 = 362, 810
    boxes = [(80, y1, 500, y2), (545, y1, 965, y2), (1010, y1, 1430, y2), (1475, y1, 1840, y2)]
    card(draw, boxes[0], 'TRAGAMONEDAS', 'Gira los rodillos', '#6B2DA3', True)
    card(draw, boxes[1], 'RULETA', 'Elige tus fichas', '#9B2335', False)
    card(draw, boxes[2], 'BLACKJACK', 'Suma 21', '#295E9C', False)
    card(draw, boxes[3], 'BONUS DIARIO', 'Reclama fichas', '#487B37', False)
    draw.rounded_rectangle((80, 893, 1840, 984), 22, fill='#0A1E31', outline='#274B68', width=2)
    draw.text((118, 918), '◀  SELECCIONA UN JUEGO', font=font(29, True), fill=GOLD_LIGHT)
    draw.text((1472, 918), '●  CONFIRMAR', font=font(29, True), fill=CREAM)
    return image


def slots_screen():
    image, draw = base_canvas('CASINO ROYAL MOBILE', 'TRAGAMONEDAS', '12,540')
    draw.rounded_rectangle((180, 196, 1740, 766), 44, fill='#160F2A', outline=GOLD, width=8)
    draw.rounded_rectangle((220, 238, 1700, 704), 28, fill='#090D18', outline='#3A245B', width=4)
    symbols = [('★', '#E2B94F'), ('♛', '#EDE7D1'), ('7', '#DC3348'), ('♦', '#35B876'), ('♛', '#EDE7D1')]
    reel_w = 236
    for index, (symbol, color) in enumerate(symbols):
        x = 252 + index * 288
        draw.rounded_rectangle((x, 282, x + reel_w, 658), 22, fill='#F8F4E7', outline=GOLD_LIGHT, width=4)
        draw.rectangle((x, 407, x + reel_w, 534), fill='#FFFDF7')
        draw.text((x + 76, 357), symbol, font=font(102, True), fill=color)
        draw.text((x + 76, 484), symbol, font=font(102, True), fill=color)
        draw.text((x + 76, 611), symbol, font=font(102, True), fill=color)
    draw.rounded_rectangle((746, 813, 1174, 978), 45, fill=GOLD, outline=GOLD_LIGHT, width=7)
    shadowed_text(draw, (844, 855), 'GIRAR', font(55, True), NAVY, shadow=(0, 3), shadow_fill='#B58019')
    draw.rounded_rectangle((80, 824, 534, 959), 30, fill='#0C2A43', outline='#2C5473', width=3)
    draw.text((118, 850), 'APUESTA', font=font(23, True), fill=MUTED)
    draw.text((118, 885), '250  FICHAS', font=font(38, True), fill=CREAM)
    draw.rounded_rectangle((1390, 824, 1840, 959), 30, fill='#0C2A43', outline='#2C5473', width=3)
    draw.text((1430, 850), 'PREMIO', font=font(23, True), fill=MUTED)
    draw.text((1430, 885), '2,500', font=font(38, True), fill=GOLD_LIGHT)
    return image


def roulette_screen():
    image, draw = base_canvas('CASINO ROYAL MOBILE', 'RULETA', '12,540')
    cx, cy = 535, 516
    for radius, color in [(330, GOLD), (304, BURGUNDY), (272, '#141923'), (234, '#E0B84C'), (196, '#0E1B27')]:
        draw.ellipse((cx - radius, cy - radius, cx + radius, cy + radius), fill=color)
    for n in range(20):
        angle = 2 * math.pi * n / 20 - math.pi / 2
        x1 = cx + math.cos(angle) * 197
        y1 = cy + math.sin(angle) * 197
        x2 = cx + math.cos(angle) * 294
        y2 = cy + math.sin(angle) * 294
        draw.line((x1, y1, x2, y2), fill=CREAM, width=4)
    draw.ellipse((cx - 105, cy - 105, cx + 105, cy + 105), fill=GREEN, outline=GOLD_LIGHT, width=5)
    draw.text((cx - 52, cy - 47), '0', font=font(88, True), fill=CREAM)
    x0, y0 = 920, 206
    draw.rounded_rectangle((x0, y0, 1815, 788), 30, fill='#064B37', outline=GOLD, width=5)
    cells = [('1', RED), ('2', BLACK), ('3', RED), ('4', BLACK), ('5', RED), ('6', BLACK), ('7', RED), ('8', BLACK), ('9', RED), ('10', BLACK), ('11', RED), ('12', BLACK)]
    for index, (label, color) in enumerate(cells):
        col = index % 3
        row = index // 3
        x = x0 + 48 + col * 278
        y = y0 + 62 + row * 112
        selected = label == '7'
        draw.rounded_rectangle((x, y, x + 235, y + 82), 16, fill=color, outline=GOLD_LIGHT if selected else CREAM, width=8 if selected else 2)
        draw.text((x + 96, y + 15), label, font=font(38, True), fill=CREAM)
    draw.rounded_rectangle((920, 834, 1290, 974), 36, fill=GOLD, outline=GOLD_LIGHT, width=7)
    shadowed_text(draw, (1014, 876), 'GIRAR', font(49, True), NAVY, shadow=(0, 3), shadow_fill='#B58019')
    draw.rounded_rectangle((1340, 834, 1815, 974), 36, fill='#0C2A43', outline='#2C5473', width=3)
    draw.text((1382, 855), 'APUESTA', font=font(23, True), fill=MUTED)
    draw.text((1382, 893), '500  FICHAS', font=font(36, True), fill=CREAM)
    draw.text((110, 884), 'ROJO', font=font(30, True), fill=RED)
    draw.text((110, 929), 'NEGRO', font=font(30, True), fill=CREAM)
    return image


screens = [
    ('casino-royal-firetv-inicio-1920x1080.jpg', home_screen()),
    ('casino-royal-firetv-tragamonedas-1920x1080.jpg', slots_screen()),
    ('casino-royal-firetv-ruleta-1920x1080.jpg', roulette_screen()),
]

for name, image in screens:
    image.save(OUT / name, 'JPEG', quality=95, optimize=True, progressive=True)
    print(f'Created {OUT / name}')
