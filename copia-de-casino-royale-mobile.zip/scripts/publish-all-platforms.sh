#!/usr/bin/env bash

set -euo pipefail

echo "Casino Royal Mobile — compilación para distribución"
echo "Elige uno de los perfiles EAS: amazon, google-play o preview."
echo "Ejemplo: ./scripts/build-and-publish.sh amazon"
echo "La publicación en cada tienda se completa manualmente después de revisar el binario y los metadatos."
