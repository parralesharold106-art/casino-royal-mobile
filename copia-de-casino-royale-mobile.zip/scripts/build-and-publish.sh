#!/usr/bin/env bash

set -euo pipefail

PROFILE="${1:-amazon}"

case "$PROFILE" in
  amazon|google-play|preview) ;;
  *)
    echo "Perfil no válido: $PROFILE"
    echo "Uso: ./scripts/build-and-publish.sh [amazon|google-play|preview]"
    exit 1
    ;;
esac

echo "Validando Casino Royal Mobile para el perfil: $PROFILE"
npm exec --yes pnpm@9.12.0 -- install --frozen-lockfile
npm exec --yes pnpm@9.12.0 -- run validate:release

echo "Iniciando la compilación EAS para Android"
npx eas-cli@latest build --platform android --profile "$PROFILE"
