# Casino Royal Mobile - TODO

## Fase 1: Configuración y Branding
- [x] Generar logo personalizado para la app
- [x] Actualizar app.config.ts con nombre y logo
- [x] Configurar colores del tema en theme.config.js

## Fase 2: Pantalla de Inicio
- [x] Crear componente BalanceDisplay
- [x] Crear pantalla Home con grid de juegos
- [x] Implementar navegación a juegos
- [x] Mostrar saldo actual

## Fase 3: Juego de Tragamonedas
- [x] Crear componente de rodillos animados
- [x] Implementar lógica de apuesta
- [x] Implementar lógica de girar y resultados
- [x] Agregar animaciones de rodillos
- [x] Actualizar saldo después de jugar

## Fase 4: Juego de Ruleta
- [x] Crear componente de rueda de ruleta
- [x] Implementar opciones de apuesta
- [x] Implementar lógica de girar
- [x] Agregar animaciones de rueda
- [x] Actualizar saldo después de jugar

## Fase 5: Juego de Blackjack
- [x] Crear componente de cartas
- [x] Implementar lógica de blackjack
- [x] Crear interfaz de decisiones (Pedir/Plantarse/Doblar)
- [x] Implementar lógica de dealer
- [x] Actualizar saldo después de jugar

## Fase 6: Pantalla de Perfil
- [x] Crear pantalla de perfil/configuración
- [x] Mostrar estadísticas de juego
- [x] Implementar opción de reiniciar saldo
- [x] Agregar selector de tema

## Fase 7: Persistencia de Datos
- [x] Guardar saldo en AsyncStorage
- [x] Guardar historial de juegos
- [x] Cargar datos al iniciar app

## Fase 8: Pulido y Entrega
- [x] Agregar feedback haptic
- [x] Agregar sonidos de juego
- [x] Optimizar animaciones
- [x] Pruebas finales
- [ ] Crear checkpoint final


## Fase 9: Autenticación y Verificación de Edad
- [ ] Implementar sistema de registro/login
- [ ] Agregar verificación de edad (18+)
- [ ] Integrar autenticación con Google/Apple
- [ ] Crear pantalla de onboarding

## Fase 10: Sistema de Billetera Virtual
- [ ] Crear modelo de billetera en base de datos
- [ ] Implementar pantalla de billetera
- [ ] Integrar PayPal SDK
- [ ] Crear flujo de depósito

## Fase 11: Compra de Fichas Premium
- [ ] Crear catálogo de paquetes de fichas
- [ ] Implementar pantalla de tienda
- [ ] Integrar procesamiento de pagos
- [ ] Agregar historial de transacciones

## Fase 12: Publicidad y Referidos
- [ ] Integrar Google AdMob
- [ ] Crear sistema de códigos de referido
- [ ] Implementar bonificaciones por referido
- [ ] Agregar pantalla de referidos

## Fase 13: Panel de Administración
- [ ] Crear dashboard para el dueño
- [ ] Mostrar estadísticas de ingresos
- [ ] Crear gestión de usuarios
- [ ] Implementar reportes

## Fase 14: Base de Datos en la Nube
- [ ] Configurar PostgreSQL en servidor
- [ ] Migrar datos de AsyncStorage
- [ ] Implementar sincronización
- [ ] Agregar backups automáticos

## Fase 15: Cumplimiento Legal (México)
- [ ] Agregar términos y condiciones
- [ ] Implementar política de privacidad
- [ ] Agregar advertencia de juego responsable
- [ ] Configurar límites de apuesta

## Fase 16: Testing y Publicación
- [ ] Pruebas de seguridad
- [ ] Pruebas de pagos
- [ ] Preparar para App Store
- [ ] Preparar para Google Play


## Fase 17: Implementación de Monetización (COMPLETADA)
- [x] Crear tablas de base de datos para monetización
- [x] Implementar funciones de billetera
- [x] Crear APIs de transacciones
- [x] Implementar verificación de edad
- [x] Crear pantalla de login con autenticación
- [x] Crear tienda de fichas con PayPal
- [x] Crear pantalla de billetera
- [x] Integrar APIs de monetización en frontend

## Fase 18: Panel de Administración
- [ ] Crear dashboard para ver estadísticas
- [ ] Mostrar ingresos totales
- [ ] Mostrar usuarios activos
- [ ] Crear gestión de paquetes de fichas
- [ ] Implementar reportes de transacciones

## Fase 19: Configuración de Producción
- [ ] Configurar variables de entorno de PayPal
- [ ] Configurar webhooks de PayPal
- [ ] Implementar logging y monitoreo
- [ ] Configurar backups automáticos
- [ ] Implementar rate limiting

## Fase 20: Cumplimiento Legal México
- [ ] Agregar términos y condiciones
- [ ] Agregar política de privacidad
- [ ] Agregar aviso de juego responsable
- [ ] Implementar límites de apuesta
- [ ] Configurar datos de contacto legal

## Fase 21: Testing y QA
- [ ] Pruebas de flujo de compra
- [ ] Pruebas de retiro
- [ ] Pruebas de seguridad
- [ ] Pruebas de rendimiento
- [ ] Pruebas en dispositivos reales

## Fase 22: Publicación
- [ ] Preparar para App Store
- [ ] Preparar para Google Play
- [ ] Crear screenshots y descripción
- [ ] Configurar precios y disponibilidad
- [ ] Publicar versión beta


## Fase 23: Integración de Múltiples Métodos de Pago (COMPLETADA)
- [x] Agregar tablas de Santander Banca Móvil
- [x] Agregar tablas de Open Bank
- [x] Agregar tablas de Mercado Pago
- [x] Crear funciones de base de datos para cada proveedor
- [x] Implementar APIs de Santander
- [x] Implementar APIs de Open Bank
- [x] Implementar APIs de Mercado Pago
- [x] Crear pantalla de selección de métodos de pago
- [x] Actualizar tienda con opciones de pago
- [x] Integrar webhooks de pagos

## Fase 24: Configuración de Credenciales de Pago
- [ ] Configurar credenciales de Santander
- [ ] Configurar credenciales de Open Bank
- [ ] Configurar credenciales de Mercado Pago
- [ ] Configurar webhooks en cada plataforma
- [ ] Realizar transacciones de prueba

## Fase 25: Panel de Administración
- [ ] Crear dashboard de ingresos
- [ ] Mostrar estadísticas por método de pago
- [ ] Crear reportes de transacciones
- [ ] Implementar gestión de usuarios
- [ ] Crear alertas de fraude

## Fase 26: Testing y Validación
- [ ] Pruebas de compra con PayPal
- [ ] Pruebas de compra con Santander
- [ ] Pruebas de compra con Open Bank
- [ ] Pruebas de compra con Mercado Pago
- [ ] Pruebas de retiro de fondos
- [ ] Pruebas de seguridad

## Fase 27: Publicación Final
- [ ] Revisar cumplimiento legal
- [ ] Realizar pruebas finales
- [ ] Preparar para App Store
- [ ] Preparar para Google Play
- [ ] Lanzamiento oficial


## Fase 28: Integración de Nubank y Clip (COMPLETADA)
- [x] Crear funciones de base de datos para Nubank
- [x] Crear funciones de base de datos para Clip
- [x] Implementar APIs de Nubank
- [x] Implementar APIs de Clip
- [x] Crear pantalla de métodos de pago extendida
- [x] Agregar routers para Nubank y Clip
- [x] Crear documento de configuración de credenciales

## Fase 29: Integración de Redsys México (COMPLETADA)
- [x] Crear módulo de integración con Redsys México
- [x] Configurar autenticación con credenciales de Sandbox
- [x] Agregar endpoints de pago en router tRPC
- [x] Conectar con sistema de transacciones
- [x] Corregir tipos de TypeScript
- [x] Crear landing page y panel de administración
- [x] Crear guía de credenciales API

## Fase 30: Esperando Credenciales del Usuario
- [ ] Recibir credenciales de PayPal
- [ ] Recibir credenciales de Mercado Pago
- [ ] Recibir credenciales de Santander
- [ ] Recibir credenciales de Open Bank
- [ ] Recibir credenciales de Nubank
- [ ] Recibir credenciales de Clip
- [ ] Recibir credenciales de Google AdMob


## Fase 31: Google AdMob, Bonificaciones Diarias y Notificaciones Push (COMPLETADA)
- [x] Crear módulo de integración con Google AdMob
- [x] Crear servicio de bonificaciones diarias automáticas
- [x] Crear servicio de notificaciones push
- [x] Agregar tablas de base de datos para AdMob, bonificaciones y notificaciones
- [x] Crear endpoints tRPC para bonificaciones
- [x] Crear endpoints tRPC para notificaciones
- [x] Crear endpoints tRPC para AdMob
- [x] Crear pantalla de bonificaciones diarias
- [x] Crear pantalla de notificaciones y preferencias
- [x] Agregar rutas a los tabs de navegación
- [x] Integrar funciones de base de datos para bonificaciones y notificaciones

## Fase 32: Generación de Ingresos Automática
- [x] Sistema de bonificaciones diarias (aumenta retención)
- [x] Publicidad integrada con Google AdMob (ingresos pasivos)
- [x] Notificaciones push (aumenta engagement y retención)
- [x] Sistema de referidos (crecimiento viral)
- [x] Múltiples métodos de pago (7 opciones)
- [x] Tienda de fichas premium
- [x] Sistema VIP con suscripción
- [x] Cosmética y efectos especiales
- [x] Desafíos y torneos con premios
- [x] Tabla de clasificación global

## Fase 33: Activos de publicación Fire TV
- [x] Generar tres capturas horizontales Fire TV de 1920 × 1080 sin transparencia para Amazon Appstore
- [x] Entregar tres archivos individuales descargables de capturas Fire TV

## Fase 34: Preparación para Amazon Appstore
- [ ] Auditar la ficha de Amazon y producir un paquete Android válido para distribución
- [ ] Restaurar la dependencia de compilación babel-preset-expo y validar la configuración Android

## Fase 35: Operación en Amazon Appstore
- [ ] Revisar y completar la ficha de Amazon con el APK válido ya cargado
- [ ] Verificar que el binario de GitHub/EAS no ofrezca juego con dinero real, retiros ni compras digitales fuera de Amazon IAP
- [ ] Sustituir textos y flujos no conformes de la tienda por una economía virtual no convertible, si la versión enviada contiene esos elementos
- [x] Corregir el solapamiento de opciones detectado por Amazon en la experiencia Fire TV
- [x] Eliminar entradas de pestañas no válidas y ocultar la barra móvil en dispositivos de TV
- [x] Ajustar los grupos de accesos y controles de juego para que se distribuyan sin superposición
- [x] Añadir una prueba determinista de los puntos de corte del diseño para Fire TV
- [ ] Añadir la descripción obligatoria en inglés a los detalles de Amazon Appstore
- [ ] Sustituir los recursos gráficos que no reflejan con precisión la experiencia real de la app

## Fase 37: Reenvío de Amazon Appstore
- [x] Entregar la descripción en inglés conforme para la ficha de Amazon
- [ ] Obtener tres capturas auténticas de 1920 × 1080 desde el APK corregido

## Fase 38: Corrección crítica de Tragamonedas
- [x] Diagnosticar el cierre inesperado al pulsar Girar
- [x] Corregir la lógica de giro, animación y actualización de saldo
- [x] Añadir prueba determinista del flujo de giro y validar el build

## Fase 39: Entrega de corrección para GitHub y EAS
- [x] Verificar y entregar el paquete fuente actualizado con el arreglo de Tragamonedas

## Fase 40: Capturas auténticas desde APK
- [x] Validar el APK recibido y confirmar que incluye el paquete y la corrección esperados
- [ ] Generar un APK actualizado con `com.casinomobile.app` y la corrección de Tragamonedas
- [ ] Ejecutar el APK o determinar el método de captura compatible con el binario
- [ ] Entregar tres capturas de pantalla compatibles con Amazon Appstore

## Fase 41: Compras dentro de la aplicación para Amazon
- [x] Auditar las dependencias y flujos actuales de compras para identificar uso de Google Play Billing o pagos externos
- [x] Diseñar e integrar el proveedor Amazon IAP para el perfil de compilación Amazon
- [ ] Validar la configuración de Amazon IAP y los identificadores de productos antes del build final
- [x] Generar y entregar el ZIP fuente actualizado con la integración RevenueCat para GitHub

## Fase 42: Guía de configuración Amazon y EAS
- [x] Entregar el procedimiento para AppstoreAuthenticationKey.pem y variables de entorno EAS/GitHub

## Fase 43: Correcciones de rechazo de Amazon
- [ ] Diagnosticar el cierre con pantalla blanca reportado por Amazon
- [ ] Corregir el botón de juego que no responde durante la revisión de Amazon
- [ ] Preparar un paquete completo y validado para Expo, GitHub y EAS
- [ ] Obtener tres capturas auténticas del APK sin fallos para Amazon

## Fase 44: ZIP limpio y actualización de GitHub
- [x] Crear un flujo seguro para actualizar GitHub desde el ZIP sin binarios, secretos ni dependencias instaladas
- [x] Generar y verificar el ZIP limpio con la integración RevenueCat

## Fase 36: Entrega de código fuente para GitHub y EAS
- [x] Auditar los archivos, scripts y configuración de compilación incluidos en el repositorio
- [x] Completar los perfiles EAS y el flujo de GitHub para Amazon Appstore
- [x] Generar un archivo ZIP íntegro de código fuente sin secretos ni dependencias instaladas
- [x] Ejecutar instalación limpia, TypeScript, pruebas automatizadas y validación de configuración antes de la entrega
- [x] Corregir la prueba de PayPal para usar credenciales ficticias y no exigir secretos de producción
- [x] Eliminar las advertencias de lint restantes para entregar un repositorio limpio
- [x] Sustituir todas las referencias heredadas de Casino Royale por Casino Royal en código y documentación
