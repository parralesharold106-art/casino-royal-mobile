const fs = require("node:fs");
const path = require("node:path");
const {
  withAndroidManifest,
  withDangerousMod,
} = require("@expo/config-plugins");

const AMAZON_TESTER_PACKAGE = "com.amazon.sdktestclient";
const AMAZON_APPSTORE_PACKAGE = "com.amazon.venezia";
const AMAZON_RESPONSE_RECEIVER = "com.amazon.device.iap.ResponseReceiver";

function addAmazonIapManifestEntries(config) {
  return withAndroidManifest(config, (mod) => {
    const manifest = mod.modResults.manifest;
    const application = manifest.application?.[0];
    if (!application) {
      throw new Error("Amazon RevenueCat plugin could not find the Android application manifest entry.");
    }

    const queries = (manifest.queries ??= [{}]);
    const packageQueries = (queries[0].package ??= []);
    for (const packageName of [AMAZON_TESTER_PACKAGE, AMAZON_APPSTORE_PACKAGE]) {
      if (!packageQueries.some((entry) => entry.$?.["android:name"] === packageName)) {
        packageQueries.push({ $: { "android:name": packageName } });
      }
    }

    const receivers = (application.receiver ??= []);
    if (!receivers.some((receiver) => receiver.$?.["android:name"] === AMAZON_RESPONSE_RECEIVER)) {
      receivers.push({
        $: {
          "android:name": AMAZON_RESPONSE_RECEIVER,
          "android:exported": "true",
          "android:permission": "com.amazon.inapp.purchasing.Permission.NOTIFY",
        },
        "intent-filter": [
          {
            action: [{ $: { "android:name": "com.amazon.inapp.purchasing.NOTIFY" } }],
          },
        ],
      });
    }

    return mod;
  });
}

function copyAmazonPublicKey(config, options) {
  return withDangerousMod(config, ["android", async (mod) => {
    if (process.env.APP_STORE !== "amazon") return mod;

    const relativeKeyPath = options?.publicKeyPath ?? "assets/amazon/AppstoreAuthenticationKey.pem";
    const sourcePath = path.resolve(mod.modRequest.projectRoot, relativeKeyPath);
    if (!fs.existsSync(sourcePath)) {
      throw new Error(
        `Amazon RevenueCat build requires ${relativeKeyPath}. Download AppstoreAuthenticationKey.pem from Amazon Developer Console and place it at that path before building.`,
      );
    }

    const assetsDirectory = path.join(mod.modRequest.platformProjectRoot, "app", "src", "main", "assets");
    fs.mkdirSync(assetsDirectory, { recursive: true });
    fs.copyFileSync(sourcePath, path.join(assetsDirectory, "AppstoreAuthenticationKey.pem"));
    return mod;
  }]);
}

module.exports = function withAmazonRevenueCat(config, options = {}) {
  if (process.env.APP_STORE !== "amazon") return config;
  config = addAmazonIapManifestEntries(config);
  return copyAmazonPublicKey(config, options);
};
