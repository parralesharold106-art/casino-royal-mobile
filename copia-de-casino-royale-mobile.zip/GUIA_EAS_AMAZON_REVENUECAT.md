# Guía paso a paso: Amazon IAP, `AppstoreAuthenticationKey.pem` y variables EAS

Esta guía prepara **una actualización futura** de Casino Royal Mobile. La versión ya aprobada por Amazon no cambia hasta que usted genere y envíe voluntariamente un nuevo APK.

> **Principio de seguridad.** La clave pública de RevenueCat se incorpora al cliente y, por ello, no es secreta. En cambio, la **Secret API Key** de RevenueCat nunca debe colocarse en `app.config.ts`, GitHub, EAS ni el APK; debe permanecer exclusivamente en el backend. Expo advierte que cualquier valor incluido en el código cliente debe considerarse público.[1]

| Elemento | Dónde se configura | Uso | ¿Se envía al APK? |
|---|---|---|---|
| `AppstoreAuthenticationKey.pem` | Repositorio, en `assets/amazon/` | Habilita Amazon Appstore SDK IAP en Android | Sí, como activo requerido por Amazon |
| `EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY` | Entorno EAS de producción y secreto de GitHub | Inicializa RevenueCat con `useAmazon: true` | Sí; es una clave pública SDK |
| `REVENUECAT_SECRET_API_KEY` | Backend únicamente | Verificación administrativa de compras | **No** |
| `EXPO_TOKEN` | Secreto de GitHub | Autoriza el flujo GitHub Actions para invocar EAS | **No** |

## 1. Confirme la rama y el proyecto EAS

Suba el ZIP actualizado de RevenueCat a una rama dedicada, por ejemplo `feature/amazon-revenuecat`, y conserve la versión actual aprobada sin cambios. En la raíz del repositorio, ejecute los siguientes comandos con su sesión de Expo:

```bash
npx eas-cli@latest whoami
npx eas-cli@latest project:info
```

Si el segundo comando no reconoce el proyecto, ejecute una sola vez:

```bash
npx eas-cli@latest init
```

El proyecto ya contiene el perfil `amazon`, que produce un APK, fija `APP_STORE=amazon` y utiliza el entorno EAS `production`.

## 2. Cree los productos en Amazon Appstore

Abra **Amazon Developer Console → App List → Casino Royal Mobile → In-App Items**. Cree primero los productos que venderá en la siguiente actualización: consumibles para fichas virtuales, suscripciones para VIP o entitlements para contenido no consumible. Los SKU son sensibles a mayúsculas y deben ser únicos; mantenga exactamente los mismos identificadores al importarlos en RevenueCat.[2]

No cree ni publique productos que prometan efectivo, retiros, premios con valor monetario o conversión de fichas a dinero. Para esta app, las fichas se describen como virtuales y sin valor monetario.

## 3. Obtenga y coloque `AppstoreAuthenticationKey.pem`

Desde la sección de Amazon Developer Console que administra la clave de autenticación del **Appstore SDK**, descargue el archivo público denominado exactamente:

```text
AppstoreAuthenticationKey.pem
```

No lo renombre. En la raíz del repositorio, cree el directorio si aún no existe y copie el archivo en esta ruta exacta:

```text
assets/amazon/AppstoreAuthenticationKey.pem
```

Compruebe la ruta antes de confirmar los cambios:

```bash
ls -l assets/amazon/AppstoreAuthenticationKey.pem
git status --short assets/amazon/AppstoreAuthenticationKey.pem
```

El complemento nativo del proyecto detiene deliberadamente el build `amazon` si este archivo no existe. Durante el prebuild, lo copia a los activos Android generados. Amazon requiere además que las aplicaciones que apunten a Android API 30 o superior declaren consultas para Amazon Appstore y App Tester, y reciban los intents de `ResponseReceiver`; el complemento realiza esas modificaciones automáticamente.[3]

## 4. Configure la clave pública de RevenueCat en EAS

En RevenueCat, abra la aplicación de Amazon cuyo paquete sea exactamente **`com.casinomobile.app`**. Copie la **Amazon Public SDK Key**, no la Secret API Key.

En una terminal autenticada en Expo, establezca la variable de producción:

```bash
npx eas-cli@latest env:set \
  --name EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY \
  --value "PEGA_AQUI_LA_AMAZON_PUBLIC_SDK_KEY" \
  --environment production \
  --visibility plaintext
```

La visibilidad `plaintext` es correcta para esta clave SDK porque se entrega al cliente. No use ese comando para `REVENUECAT_SECRET_API_KEY`.

Compruebe que EAS la reconozca, sin imprimir su valor:

```bash
npx eas-cli@latest env:list --environment production
```

EAS separa variables por entorno y recomienda asociar explícitamente el perfil de build con `production`; este repositorio ya incorpora esa asociación en `eas.json`.[1]

## 5. Configure GitHub Actions

En GitHub, abra **Settings → Secrets and variables → Actions → New repository secret**. Cree estas dos entradas:

| Nombre exacto | Valor que debe pegar |
|---|---|
| `EXPO_TOKEN` | Token personal de Expo con permisos para ejecutar EAS Build |
| `EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY` | La misma Amazon Public SDK Key configurada en EAS |

El flujo de GitHub usa la segunda variable para ejecutar la validación del código. El build remoto utiliza el entorno `production` de EAS definido en el paso anterior.

## 6. Configure el catálogo en RevenueCat

En RevenueCat, añada la tienda **Amazon Appstore** con el paquete `com.casinomobile.app`. Importe los SKU creados en Amazon, asígnelos a los entitlements adecuados —por ejemplo, `vip`— y añádalos al **Current Offering**. La app muestra los paquetes disponibles de ese offering únicamente cuando `APP_STORE=amazon`.

> RevenueCat documenta que un SKU de Amazon debe ser único, sensible a mayúsculas y configurarse primero en Amazon Appstore antes de integrarlo en RevenueCat.[2]

## 7. Valide localmente antes de compilar

Después de crear la variable de EAS, puede traer una copia temporal al entorno local para inspeccionar la configuración. No suba el archivo resultante al repositorio:

```bash
npx eas-cli@latest env:pull --environment production
APP_STORE=amazon npx expo config --type public
npm exec --yes pnpm@9.12.0 -- run validate:release
```

La salida debe conservar el paquete `com.casinomobile.app`, mostrar `distributionStore: amazon` durante la comprobación con `APP_STORE=amazon`, y completar TypeScript, pruebas, lint y validación EAS.

## 8. Cree el próximo APK de Amazon

Cuando los SKU estén disponibles en Amazon, el Current Offering esté configurado en RevenueCat y el archivo PEM exista, ejecute:

```bash
npx eas-cli@latest build --platform android --profile amazon
```

Como alternativa, en GitHub abra **Actions → Build Android for Amazon or Google Play → Run workflow → amazon**. No sustituya la versión aprobada actualmente; envíe este APK como una actualización posterior y pruebe el flujo de compra en un dispositivo Amazon con una cuenta de prueba antes de enviarlo a revisión.

## 9. Lista de comprobación final

| Verificación | Debe ser verdadero antes del build |
|---|---|
| Paquete | `com.casinomobile.app` |
| Archivo | `assets/amazon/AppstoreAuthenticationKey.pem` existe y conserva ese nombre |
| EAS | `EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY` existe en `production` |
| GitHub | `EXPO_TOKEN` y la clave pública RevenueCat están creados como secretos |
| Amazon | Los SKU están creados y enviados en In-App Items |
| RevenueCat | Productos importados, entitlements asignados y Current Offering activo |
| Código | El perfil `amazon` se ejecuta con `useAmazon: true` y no muestra PayPal |

## 10. Mensaje de commit recomendado

```text
feat(amazon): integrar RevenueCat con Amazon IAP y separar pagos externos
```

### Referencias

[1]: https://docs.expo.dev/eas/environment-variables/ "Expo: Variables de entorno en EAS"
[2]: https://www.revenuecat.com/docs/getting-started/entitlements/amazon-product-setup "RevenueCat: Amazon Product Setup"
[3]: https://developer.amazon.com/docs/in-app-purchasing/iap-implement-iap.html "Amazon: Implement Appstore SDK IAP"
