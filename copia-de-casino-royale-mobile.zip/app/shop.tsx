import { ActivityIndicator, Pressable, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import * as Haptics from "expo-haptics";
import type { PurchasesPackage } from "react-native-purchases";

import { ScreenContainer } from "@/components/screen-container";
import {
  getAmazonPackages,
  isAmazonRevenueCatBuild,
  purchaseAmazonPackage,
} from "@/lib/revenuecat";
import { trpc } from "@/lib/trpc";

interface ChipPackage {
  id: number;
  name: string;
  chips: number;
  priceInDollars: string;
  bonus: number;
  isActive: number;
}

export default function ShopScreen() {
  const router = useRouter();
  const [selectedPackage, setSelectedPackage] = useState<ChipPackage | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [amazonPackages, setAmazonPackages] = useState<PurchasesPackage[]>([]);
  const [amazonError, setAmazonError] = useState<string | null>(null);
  const isAmazonBuild = isAmazonRevenueCatBuild();

  const { data: packages, isLoading } = trpc.chipPackages.list.useQuery();
  const paypalMutation = trpc.paypal.createOrder.useMutation();

  useEffect(() => {
    if (!isAmazonBuild) return;

    void getAmazonPackages()
      .then(setAmazonPackages)
      .catch((error) => {
        console.error("Amazon offerings error:", error);
        setAmazonError("No fue posible cargar los productos de Amazon. Intenta de nuevo más tarde.");
      });
  }, [isAmazonBuild]);

  const handleBuyChips = async (pkg: ChipPackage) => {
    setSelectedPackage(pkg);
    setIsProcessing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      await paypalMutation.mutateAsync({
        packageId: pkg.id,
        amount: pkg.priceInDollars,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error("Purchase error:", error);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAmazonPurchase = async (aPackage: PurchasesPackage) => {
    setIsProcessing(true);
    try {
      await purchaseAmazonPackage(aPackage);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error("Amazon purchase error:", error);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!isAmazonBuild && isLoading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color="#d4af37" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-4">
          <View className="flex-row items-center justify-between">
            <Pressable onPress={() => router.back()} style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}>
              <Text className="text-2xl">←</Text>
            </Pressable>
            <Text className="text-lg font-bold text-primary">Tienda de Fichas</Text>
            <View className="w-6" />
          </View>

          <View className="bg-surface rounded-2xl p-4 border border-border">
            <Text className="text-sm text-muted text-center">
              {isAmazonBuild
                ? "Compra contenido digital mediante Amazon Appstore. Las fichas virtuales no tienen valor monetario ni se pueden retirar."
                : "Las fichas virtuales se usan únicamente para entretenimiento dentro de la aplicación."}
            </Text>
          </View>

          <View className="gap-3">
            {isAmazonBuild && amazonError && (
              <Text className="text-sm text-error text-center">{amazonError}</Text>
            )}
            {isAmazonBuild && !amazonError && amazonPackages.length === 0 && (
              <ActivityIndicator size="small" color="#d4af37" />
            )}
            {isAmazonBuild && amazonPackages.map((aPackage) => (
              <View key={aPackage.identifier} className="bg-surface rounded-2xl p-4 border border-border gap-3">
                <View className="flex-row justify-between items-start">
                  <View className="flex-1">
                    <Text className="text-lg font-bold text-primary">{aPackage.product.title}</Text>
                    <Text className="text-sm text-muted mt-1">{aPackage.product.description}</Text>
                  </View>
                  <Text className="text-2xl font-bold text-primary">{aPackage.product.priceString}</Text>
                </View>
                <TouchableOpacity
                  onPress={() => handleAmazonPurchase(aPackage)}
                  disabled={isProcessing}
                  className={`py-3 rounded-lg ${isProcessing ? "bg-muted/50" : "bg-primary"}`}
                >
                  <Text className={`text-center font-bold ${isProcessing ? "text-muted" : "text-background"}`}>
                    {isProcessing ? "Procesando..." : "Comprar con Amazon"}
                  </Text>
                </TouchableOpacity>
              </View>
            ))}

            {!isAmazonBuild && packages?.map((pkg) => (
              <View key={pkg.id} className="bg-surface rounded-2xl p-4 border border-border gap-3">
                <View className="flex-row justify-between items-start">
                  <View className="flex-1">
                    <Text className="text-lg font-bold text-primary">{pkg.name}</Text>
                    <Text className="text-2xl font-bold text-foreground mt-1">{pkg.chips.toLocaleString()} 🪙</Text>
                    {pkg.bonus > 0 && <Text className="text-sm text-success mt-1">+ {pkg.bonus} bonus fichas</Text>}
                  </View>
                  <View className="items-end">
                    <Text className="text-2xl font-bold text-primary">${parseFloat(pkg.priceInDollars).toFixed(2)}</Text>
                    <Text className="text-xs text-muted mt-1">USD</Text>
                  </View>
                </View>
                <TouchableOpacity
                  onPress={() => handleBuyChips(pkg)}
                  disabled={isProcessing && selectedPackage?.id === pkg.id}
                  className={`py-3 rounded-lg ${isProcessing && selectedPackage?.id === pkg.id ? "bg-muted/50" : "bg-primary"}`}
                >
                  <Text className={`text-center font-bold ${isProcessing && selectedPackage?.id === pkg.id ? "text-muted" : "text-background"}`}>
                    {isProcessing && selectedPackage?.id === pkg.id ? "Procesando..." : "Comprar con PayPal"}
                  </Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>

          {!isAmazonBuild && (
            <View className="bg-surface rounded-2xl p-4 border border-border gap-3">
              <Text className="font-bold text-foreground">Métodos de Pago Disponibles</Text>
              <Text className="text-sm text-muted">✓ PayPal</Text>
              <Text className="text-sm text-muted">✓ Santander Banca Móvil</Text>
              <Text className="text-sm text-muted">✓ Open Bank</Text>
              <Text className="text-sm text-muted">✓ Mercado Pago</Text>
              <TouchableOpacity onPress={() => router.push("/payment-methods")} className="bg-primary py-2 rounded-lg mt-2">
                <Text className="text-center font-bold text-background text-sm">Ver Todos los Métodos</Text>
              </TouchableOpacity>
            </View>
          )}

          {!isAmazonBuild && (
            <View className="bg-success/10 border border-success rounded-lg p-4">
              <Text className="text-xs text-success text-center leading-relaxed">
                Los pagos externos se muestran únicamente en compilaciones que no son de Amazon.
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
