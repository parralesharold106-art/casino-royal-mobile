import { useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Platform, useWindowDimensions } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import Animated, { 
  useSharedValue, 
  withTiming, 
  withRepeat,
  withSequence,
  Easing,
  useAnimatedStyle
} from "react-native-reanimated";
import { ScreenContainer } from "@/components/screen-container";
import { usesWideTvLayout } from "@/lib/fire-tv-layout";
import { calculateSlotOutcome, createRandomReels, SLOT_SYMBOLS, type SlotReels } from "@/lib/slots-game";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "casino_balance";
const REEL_DURATION_MS = 800;
const REEL_STAGGER_MS = 150;

const wait = (duration: number) => new Promise<void>((resolve) => setTimeout(resolve, duration));

export default function SlotsScreen() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const usesWideLayout = usesWideTvLayout(width, Platform.isTV);
  const [balance, setBalance] = useState(0);
  const [bet, setBet] = useState(10);
  const [result, setResult] = useState<{ message: string; amount: number; isWin: boolean } | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);
  const [reels, setReels] = useState<SlotReels>([0, 0, 0]);
  const [totalWinnings, setTotalWinnings] = useState(0);
  const isMounted = useRef(true);

  // Animaciones para los rodillos
  const reel1Rotation = useSharedValue(0);
  const reel2Rotation = useSharedValue(0);
  const reel3Rotation = useSharedValue(0);
  
  // Animaciones para efectos especiales
  const winScale = useSharedValue(1);
  const winOpacity = useSharedValue(0);
  const betBoomScale = useSharedValue(0);
  const betBoomOpacity = useSharedValue(0);

  useEffect(() => {
    loadBalance();
    return () => {
      isMounted.current = false;
    };
  }, []);

  const loadBalance = async () => {
    try {
      const savedBalance = await AsyncStorage.getItem(STORAGE_KEY);
      if (savedBalance !== null) {
        setBalance(parseFloat(savedBalance));
      } else {
        setBalance(1000);
        await AsyncStorage.setItem(STORAGE_KEY, "1000");
      }
    } catch (error) {
      console.error("Error loading balance:", error);
    }
  };

  const saveBalance = async (newBalance: number) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, newBalance.toString());
      setBalance(newBalance);
    } catch (error) {
      console.error("Error saving balance:", error);
    }
  };

  const startReelAnimation = (reelIndex: number, targetRotation: number) => {
    const rotation = reelIndex === 0 ? reel1Rotation : reelIndex === 1 ? reel2Rotation : reel3Rotation;
    rotation.value = withTiming(targetRotation, {
      duration: REEL_DURATION_MS,
      easing: Easing.out(Easing.cubic),
    });
  };

  const triggerBetBoom = () => {
    // Efecto de explosión de apuesta
    betBoomScale.value = 0;
    betBoomOpacity.value = 1;
    
    betBoomScale.value = withSequence(
      withTiming(1.2, { duration: 300, easing: Easing.out(Easing.cubic) }),
      withTiming(0.8, { duration: 200, easing: Easing.in(Easing.cubic) })
    );
    
    betBoomOpacity.value = withSequence(
      withTiming(1, { duration: 300 }),
      withTiming(0, { duration: 200 })
    );

  };

  const triggerWinAnimation = () => {
    winScale.value = 1;
    winOpacity.value = 1;
    
    winScale.value = withRepeat(
      withSequence(
        withTiming(1.1, { duration: 200 }),
        withTiming(0.9, { duration: 200 })
      ),
      3,
      false
    );

  };

  const playHaptic = async (type: "success" | "light") => {
    if (Platform.OS === "web") return;
    try {
      if (type === "success") {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } else {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }
    } catch (error) {
      console.warn("Haptic feedback unavailable:", error);
    }
  };

  const spin = async () => {
    if (balance < bet || isSpinning) return;

    setIsSpinning(true);
    setResult(null);

    try {
      const newBalance = balance - bet;
      await saveBalance(newBalance);
      triggerBetBoom();
      void playHaptic("light");

      const newReels = createRandomReels();
      startReelAnimation(0, 360 * 5 + newReels[0] * 60);
      await wait(REEL_STAGGER_MS);
      startReelAnimation(1, 360 * 5 + newReels[1] * 60);
      await wait(REEL_STAGGER_MS);
      startReelAnimation(2, 360 * 5 + newReels[2] * 60);
      await wait(REEL_DURATION_MS);

      if (!isMounted.current) return;

      setReels(newReels);
      const outcome = calculateSlotOutcome(newReels, bet);
      const finalBalance = newBalance + outcome.winnings;

      if (outcome.isWin) {
        await saveBalance(finalBalance);
        setTotalWinnings((current) => current + outcome.winnings);
        triggerWinAnimation();
        void playHaptic("success");
      }

      setResult({ message: outcome.message, amount: outcome.winnings, isWin: outcome.isWin });
    } catch (error) {
      console.error("Slots spin failed:", error);
      if (isMounted.current) {
        setResult({ message: "No se pudo completar el giro. Intenta de nuevo.", amount: 0, isWin: false });
      }
    } finally {
      if (isMounted.current) {
        setIsSpinning(false);
      }
    }
  };

  const reel1AnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ rotateZ: `${reel1Rotation.value}deg` }],
  }));

  const reel2AnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ rotateZ: `${reel2Rotation.value}deg` }],
  }));

  const reel3AnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ rotateZ: `${reel3Rotation.value}deg` }],
  }));

  const winAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: winScale.value }],
    opacity: winOpacity.value,
  }));

  const betBoomAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: betBoomScale.value }],
    opacity: betBoomOpacity.value,
  }));

  return (
    <ScreenContainer className="bg-gradient-to-b from-slate-900 to-slate-800">
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={[styles.content, usesWideLayout && styles.contentWide]}>
        {/* Header */}
        <View className="flex-row justify-between items-center mb-6">
          <TouchableOpacity onPress={() => router.back()} className="p-2">
            <Text className="text-white text-lg">←</Text>
          </TouchableOpacity>
          <Text className="text-2xl font-bold text-yellow-400">🎰 TRAGAMONEDAS</Text>
          <View className="w-8" />
        </View>

        {/* Saldo */}
        <View className="bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-lg p-4 mb-4">
          <Text className="text-slate-900 text-sm font-semibold">Tu Saldo</Text>
          <Text className="text-slate-900 text-3xl font-bold">${balance.toFixed(2)}</Text>
        </View>

        {/* Rodillos */}
        <View className="bg-slate-800 rounded-2xl p-6 mb-6 border-2 border-yellow-400">
          <View className="flex-row justify-around items-center mb-4">
            {/* Reel 1 */}
            <Animated.View style={[reel1AnimatedStyle]} className="w-20 h-20 bg-slate-700 rounded-lg flex items-center justify-center border-2 border-yellow-400">
              <Text className="text-4xl">{SLOT_SYMBOLS[reels[0]]}</Text>
            </Animated.View>

            {/* Reel 2 */}
            <Animated.View style={[reel2AnimatedStyle]} className="w-20 h-20 bg-slate-700 rounded-lg flex items-center justify-center border-2 border-yellow-400">
              <Text className="text-4xl">{SLOT_SYMBOLS[reels[1]]}</Text>
            </Animated.View>

            {/* Reel 3 */}
            <Animated.View style={[reel3AnimatedStyle]} className="w-20 h-20 bg-slate-700 rounded-lg flex items-center justify-center border-2 border-yellow-400">
              <Text className="text-4xl">{SLOT_SYMBOLS[reels[2]]}</Text>
            </Animated.View>
          </View>

          {/* Bet Boom Effect */}
          <Animated.View style={[betBoomAnimatedStyle]} className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
            <Text className="text-6xl font-bold text-yellow-300">💥 BET BOOM!</Text>
          </Animated.View>
        </View>

        {/* Resultado */}
        {result && (
          <Animated.View style={[winAnimatedStyle]} className={cn(
            "rounded-lg p-4 mb-4 text-center",
            result.isWin ? "bg-green-500" : "bg-red-500"
          )}>
            <Text className="text-white text-lg font-bold">{result.message}</Text>
            {result.isWin && (
              <Text className="text-white text-2xl font-bold mt-2">+${result.amount}</Text>
            )}
          </Animated.View>
        )}

        {/* Controles de Apuesta */}
        <View className="bg-slate-700 rounded-lg p-4 mb-4">
          <Text className="text-white text-sm font-semibold mb-3">Apuesta</Text>
          <View style={styles.betOptions}>
            {[5, 10, 25, 50, 100].map((amount) => (
              <TouchableOpacity
                key={amount}
                onPress={() => setBet(amount)}
                style={styles.betOption}
                className={cn(
                  "py-2 rounded-lg",
                  bet === amount ? "bg-yellow-400" : "bg-slate-600"
                )}
              >
                <Text className={cn(
                  "text-center font-bold",
                  bet === amount ? "text-slate-900" : "text-white"
                )}>
                  ${amount}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.betStepper}>
            <TouchableOpacity
              onPress={() => setBet(Math.max(1, bet - 5))}
              style={styles.stepperButton}
              className="bg-slate-600 py-2 rounded-lg"
            >
              <Text className="text-white text-center font-bold">−</Text>
            </TouchableOpacity>
            <Text style={styles.stepperLabel} className="text-white text-xl font-bold">Apuesta: ${bet}</Text>
            <TouchableOpacity
              onPress={() => setBet(Math.min(balance, bet + 5))}
              style={styles.stepperButton}
              className="bg-slate-600 py-2 rounded-lg"
            >
              <Text className="text-white text-center font-bold">+</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Botón Girar */}
        <TouchableOpacity
          onPress={spin}
          disabled={isSpinning || balance < bet}
          className={cn(
            "py-4 rounded-lg mb-4 border-2",
            isSpinning || balance < bet
              ? "bg-slate-600 border-slate-500 opacity-50"
              : "bg-gradient-to-r from-yellow-400 to-yellow-500 border-yellow-300"
          )}
        >
          <Text className={cn(
            "text-center text-xl font-bold",
            isSpinning || balance < bet ? "text-slate-400" : "text-slate-900"
          )}>
            {isSpinning ? "GIRANDO..." : "GIRAR"}
          </Text>
        </TouchableOpacity>

        {/* Estadísticas */}
        <View className="bg-slate-700 rounded-lg p-4">
          <Text className="text-white text-sm font-semibold mb-2">Estadísticas</Text>
          <View style={styles.statistics}>
            <View style={styles.statisticItem}>
              <Text className="text-slate-400 text-xs">Ganancias Totales</Text>
              <Text className="text-green-400 text-lg font-bold">${totalWinnings}</Text>
            </View>
            <View style={styles.statisticItem}>
              <Text className="text-slate-400 text-xs">Apuesta Mínima</Text>
              <Text className="text-yellow-400 text-lg font-bold">$1</Text>
            </View>
            <View style={styles.statisticItem}>
              <Text className="text-slate-400 text-xs">Multiplicador Máx</Text>
              <Text className="text-purple-400 text-lg font-bold">50x</Text>
            </View>
          </View>
        </View>

        {/* Información */}
        <View className="bg-slate-700 rounded-lg p-4 mt-4">
          <Text className="text-yellow-400 text-xs font-semibold mb-2">💡 CÓMO JUGAR</Text>
          <Text className="text-slate-300 text-xs leading-5">
            • 3 símbolos iguales = JACKPOT (hasta 50x){"\n"}
            • 2 símbolos iguales = Gana 3x{"\n"}
            • Símbolo especial 👑 = Bonus{"\n"}
            • Juega responsablemente
          </Text>
        </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    padding: 16,
    paddingBottom: 32,
  },
  content: {
    alignSelf: "center",
    maxWidth: 720,
    width: "100%",
  },
  contentWide: {
    maxWidth: 1120,
  },
  betOptions: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginBottom: 12,
  },
  betOption: {
    flexBasis: "18%",
    minWidth: 78,
  },
  betStepper: {
    alignItems: "center",
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    justifyContent: "center",
  },
  stepperButton: {
    flex: 1,
    minWidth: 72,
  },
  stepperLabel: {
    flexShrink: 1,
    textAlign: "center",
  },
  statistics: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
    justifyContent: "space-between",
  },
  statisticItem: {
    flexBasis: "30%",
    minWidth: 150,
  },
});
