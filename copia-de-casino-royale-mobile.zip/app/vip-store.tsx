import { Alert, Pressable, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import * as Haptics from "expo-haptics";
import type { PurchasesPackage } from "react-native-purchases";

import { ScreenContainer } from "@/components/screen-container";
import {
  getAmazonPackages,
  isAmazonRevenueCatBuild,
  purchaseAmazonPackage,
} from "@/lib/revenuecat";

interface VIPTier {
  name: string;
  price: number;
  features: string[];
  color: string;
  icon: string;
}

const VIP_TIERS: VIPTier[] = [
  {
    name: "Silver",
    price: 4.99,
    features: ["Bonificación diaria de fichas virtuales", "Acceso a desafíos VIP", "Soporte prioritario"],
    color: "#C0C0C0",
    icon: "🟡",
  },
  {
    name: "Gold",
    price: 9.99,
    features: ["Bonificación diaria de fichas virtuales", "Desafíos VIP", "Giros virtuales diarios", "Soporte prioritario"],
    color: "#FFD700",
    icon: "🟢",
  },
  {
    name: "Platinum",
    price: 19.99,
    features: ["Bonificación diaria de fichas virtuales", "Desafíos exclusivos", "Animaciones avanzadas", "Soporte dedicado"],
    color: "#E5E4E2",
    icon: "🔵",
  },
];

const COSMETICS = [
  { id: 1, name: "Tema Neon", price: 2.99, icon: "🌈", description: "Colores vibrantes y futuristas" },
  { id: 2, name: "Avatar Dorado", price: 1.99, icon: "👑", description: "Avatar exclusivo dorado" },
  { id: 3, name: "Efecto Fuego", price: 0.99, icon: "🔥", description: "Efectos visuales para tus partidas" },
  { id: 4, name: "Animación Rápida", price: 1.99, icon: "⚡", description: "Animaciones más rápidas" },
];

export default function VIPStoreScreen() {
  const router = useRouter();
  const [selectedTab, setSelectedTab] = useState<"vip" | "cosmetics">("vip");
  const [currentVIP, setCurrentVIP] = useState<string | null>(null);
  const [amazonPackages, setAmazonPackages] = useState<PurchasesPackage[]>([]);
  const [amazonError, setAmazonError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const isAmazonBuild = isAmazonRevenueCatBuild();

  useEffect(() => {
    if (!isAmazonBuild) return;
    void getAmazonPackages()
      .then(setAmazonPackages)
      .catch((error) => {
        console.error("Amazon VIP offerings error:", error);
        setAmazonError("No fue posible cargar los beneficios disponibles de Amazon.");
      });
  }, [isAmazonBuild]);

  const handleAmazonPurchase = async (aPackage: PurchasesPackage) => {
    setIsProcessing(true);
    try {
      const customerInfo = await purchaseAmazonPackage(aPackage);
      const entitlement = Object.keys(customerInfo.entitlements.active)[0] ?? aPackage.product.title;
      setCurrentVIP(entitlement);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Compra completada", "Tu compra de Amazon se ha validado correctamente.");
    } catch (error) {
      console.error("Amazon VIP purchase error:", error);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert("Compra no completada", "No se pudo completar la compra con Amazon. Intenta de nuevo.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePreviewPurchase = (name: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Alert.alert("Disponible en Amazon", `${name} se compra a través de Amazon Appstore en el build de Amazon.`);
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-4">
          <View className="flex-row items-center justify-between">
            <Pressable onPress={() => router.back()} style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}>
              <Text className="text-2xl">←</Text>
            </Pressable>
            <Text className="text-lg font-bold text-primary">Tienda Premium</Text>
            <View className="w-6" />
          </View>

          {!isAmazonBuild && (
            <View className="flex-row gap-2">
              {(["vip", "cosmetics"] as const).map((tab) => (
                <TouchableOpacity
                  key={tab}
                  onPress={() => setSelectedTab(tab)}
                  className={`flex-1 py-2 rounded-lg border ${selectedTab === tab ? "bg-primary border-primary" : "bg-surface border-border"}`}
                >
                  <Text className={`text-center font-bold text-sm ${selectedTab === tab ? "text-background" : "text-foreground"}`}>
                    {tab === "vip" ? "💎 VIP" : "🎨 Cosméticos"}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {(isAmazonBuild || selectedTab === "vip") && (
            <View className="gap-4">
              {isAmazonBuild && amazonError && <Text className="text-sm text-error text-center">{amazonError}</Text>}
              {isAmazonBuild && !amazonError && amazonPackages.length === 0 && <Text className="text-sm text-muted text-center">Cargando productos de Amazon...</Text>}
              {isAmazonBuild && amazonPackages.map((aPackage) => (
                <View key={aPackage.identifier} className="rounded-2xl p-4 border-2 bg-surface border-border gap-3">
                  <View className="flex-row items-center justify-between gap-3">
                    <View className="flex-1">
                      <Text className="font-bold text-foreground">{aPackage.product.title}</Text>
                      <Text className="text-xs text-muted mt-1">{aPackage.product.description}</Text>
                    </View>
                    <Text className="text-primary font-bold">{aPackage.product.priceString}</Text>
                  </View>
                  <TouchableOpacity
                    onPress={() => handleAmazonPurchase(aPackage)}
                    disabled={isProcessing}
                    className={`py-3 rounded-lg ${isProcessing ? "bg-muted/50" : "bg-primary"}`}
                  >
                    <Text className={`text-center font-bold ${isProcessing ? "text-muted" : "text-background"}`}>
                      {isProcessing ? "Procesando..." : "Comprar con Amazon"}
                    </Text>
                  </TouchableOpacity>
                </View>
              ))}

              {!isAmazonBuild && VIP_TIERS.map((tier) => (
                <View key={tier.name} className={`rounded-2xl p-4 border-2 ${currentVIP === tier.name ? "bg-primary/20 border-primary" : "bg-surface border-border"}`}>
                  <View className="gap-3">
                    <View className="flex-row items-center justify-between">
                      <View className="flex-row items-center gap-2">
                        <Text className="text-2xl">{tier.icon}</Text>
                        <View>
                          <Text className="font-bold text-foreground">{tier.name}</Text>
                          <Text className="text-xs text-muted">${tier.price}/mes</Text>
                        </View>
                      </View>
                    </View>
                    <View className="bg-background/30 rounded-lg p-3 gap-2">
                      {tier.features.map((feature) => <Text key={feature} className="text-sm text-muted">✓ {feature}</Text>)}
                    </View>
                    <TouchableOpacity onPress={() => handlePreviewPurchase(tier.name)} className="bg-primary py-3 rounded-lg">
                      <Text className="text-center font-bold text-background">Suscribirse Ahora</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))}
            </View>
          )}

          {!isAmazonBuild && selectedTab === "cosmetics" && (
            <View className="gap-3">
              {COSMETICS.map((cosmetic) => (
                <TouchableOpacity key={cosmetic.id} onPress={() => handlePreviewPurchase(cosmetic.name)} className="bg-surface rounded-2xl p-4 border border-border flex-row items-center justify-between">
                  <View className="flex-row items-center gap-3 flex-1">
                    <Text className="text-3xl">{cosmetic.icon}</Text>
                    <View className="flex-1">
                      <Text className="font-bold text-foreground">{cosmetic.name}</Text>
                      <Text className="text-xs text-muted">{cosmetic.description}</Text>
                    </View>
                  </View>
                  <Text className="font-bold text-primary text-sm">${cosmetic.price}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          <View className="bg-primary/10 border border-primary rounded-2xl p-4 gap-2">
            <Text className="text-xs text-primary font-bold">INFORMACIÓN</Text>
            <Text className="text-xs text-muted">
              {isAmazonBuild
                ? "Las compras y suscripciones se administran de forma segura mediante Amazon Appstore."
                : "El catálogo definitivo se compra mediante Amazon Appstore en el build de Amazon."}
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
