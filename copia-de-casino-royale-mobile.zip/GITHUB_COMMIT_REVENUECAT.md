# GitHub Commit for RevenueCat Amazon Update

Use the following commit message after adding the updated source code, `AppstoreAuthenticationKey.pem`, and the RevenueCat configuration:

```text
feat(amazon): integrar RevenueCat con Amazon IAP y separar pagos externos
```

Use this optional extended commit description:

```text
- Añade react-native-purchases y configura RevenueCat con useAmazon: true.
- El perfil EAS amazon usa APP_STORE=amazon y el paquete com.casinomobile.app.
- Las tiendas de fichas y VIP cargan productos y suscripciones desde el offering de RevenueCat.
- Los pagos externos no se muestran ni se invocan en el build de Amazon.
- Añade la clave pública AppstoreAuthenticationKey.pem requerida por Amazon IAP.
```

Before opening a future Amazon update build, configure these two values:

| Location | Required value |
|---|---|
| GitHub repository secret | `EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY` |
| EAS production environment | `EXPO_PUBLIC_REVENUECAT_AMAZON_API_KEY` |

The first is used by the GitHub validation workflow. The second is injected into the remote EAS build. Both must be the RevenueCat Amazon Public SDK Key for `com.casinomobile.app`.

Then add the public Amazon file at `assets/amazon/AppstoreAuthenticationKey.pem`, commit it, and run the `amazon` workflow only for the next release after the currently approved version is published.
